# Desktop Infra Starter 架构设计（导出版）

本文为单文件导出版，可直接对外传阅。

## 1. 架构目标

1. Electron 启动时自动拉起本地 NestJS API。
2. 支持外部数据库与可选内置数据库。
3. 数据库大体积资源按需下载，不默认入仓。
4. 使用 pnpm workspace 管理 `client`、`api-serivce`、`docs` 三个独立包。

## 2. 关键组件

1. `@desktop-infra/client`：桌面壳层与前端页面。
2. `@desktop-infra/api-service`：本地接口服务与 Swagger。
3. `@desktop-infra/docs`：VitePress 文档站。
4. `scripts/download-mysql.ts`：内置 MySQL 资源下载脚本。

## 3. 启动编排

1. 主进程进入 `starting_embedded_db`（仅内置模式）。
2. 主进程进入 `starting_api` 并拉起 API。
3. 轮询 `GET /ready` 成功后进入 `ready`。
4. Preload 根据主进程状态控制全局加载遮罩。

## 4. 数据库模式

1. `DB_MODE=none`：不启用数据库。
2. `DB_MODE=external`：连接外部 MySQL。
3. `DB_MODE=embedded`：启动内置 MySQL 并连接本地端口。

## 5. 对外接口（最小）

1. `GET /health`
2. `GET /ready`
3. `GET /test/ping`
4. `GET /test/db`
5. `GET /api-docs`（Swagger UI）

## 6. 打包策略

1. 先构建 API，再执行 `prepare-pack.ts` 生成 `.pack`。
2. Electron 构建时注入 `api-serivce/.pack` 到发布资源。
3. 是否注入 MySQL 目录由是否下载资源决定。

## 7. 仓库分层（前端）

1. `views`：页面级组件。
2. `store`：运行状态管理。
3. `api`：HTTP 调用封装。
4. `utils`：工具与菜单配置。
5. `model`：类型定义。
6. `router`：路由定义。

## 8. 运行参数

1. `API_HOST` / `API_PORT`
2. `DB_MODE`
3. `MYSQL_URL`
4. `MYSQL_HOST` / `MYSQL_PORT` / `MYSQL_USER` / `MYSQL_PASSWORD` / `MYSQL_DATABASE`
5. `EMBEDDED_MYSQL_ENABLED`
6. `EMBEDDED_MYSQL_PORT`

